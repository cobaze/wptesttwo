<!DOCTYPE html>

<html>
	<head>
		<title>THIS IS MY SITE TITLE</title>

	</head>

	<body>
		<?php
		get_header(); ?>

	</body>


</html>